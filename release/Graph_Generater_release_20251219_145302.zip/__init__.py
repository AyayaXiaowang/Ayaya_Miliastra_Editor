"""右上角控件管理模块"""
from .controls_manager import TopRightControlsManager
__all__ = ["TopRightControlsManager"]

