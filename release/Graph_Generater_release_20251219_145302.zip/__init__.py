"""
应用装配层：UI、CLI 与运行态集成（依赖 engine 与 plugins）。
"""

__all__ = []


