"""运行时系统 - 让节点图代码可执行"""

from .engine.game_state import GameRuntime

__all__ = ["GameRuntime"]

