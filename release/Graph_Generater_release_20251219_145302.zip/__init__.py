"""自动排版控制器模块"""
from .auto_layout_controller import AutoLayoutController
__all__ = ["AutoLayoutController"]

