"""视图装配模块"""
from .view_assembly import ViewAssembly

__all__ = ["ViewAssembly"]

