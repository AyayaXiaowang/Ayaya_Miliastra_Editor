from .registry import install_default_main_window_features

__all__ = ["install_default_main_window_features"]


